from django.apps import AppConfig


class ChatbotappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatbotapp'
